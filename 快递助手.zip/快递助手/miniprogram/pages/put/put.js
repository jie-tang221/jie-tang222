const app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
     shows:false,
    name: "",
    tel: "",
    id: "",
    secret:"null",
    other:"",
    ok:0
  },
  nameInput: function (e) {

    this.setData({

      name: e.detail.value

    })

  },



  // 获取输入密码 

 otherInput: function (e) {

    this.setData({

     other: e.detail.value

    })

  },
  put: function () {

    if (this.data.name.length == 0 || this.data.other.length == 0) {

      wx.showToast({

        title: '信息不能为空',

        icon: 'loading',

        duration: 2000

      })

    } else {

      // 这里修改成跳转的页面 

      wx.showToast({

        title: '发布成功',

        icon: 'success',

        duration: 2000

      })

    }

  },

  switch1Change: function (e) {
    this.setData({
      shows: e.detail.value
    });
  },

  name: function (e) {
    this.setData({
      name: e.detail.value
    })
  },

  tel: function (e) {
    this.setData({
      tel: e.detail.value
    })
  },

  id: function (e) {
    this.setData({
      id: e.detail.value
    })
  },
 
  secret: function (e) {
    this.setData({
      secret: e.detail.value
    })
  },

  other: function (e) {
    this.setData({
      other: e.detail.value
    })
  },

  upload: function () {
    const db = wx.cloud.database()
    db.collection("fastpass").add({
      data: {
        name: this.data.name,
        id: this.data.id,
        tel: this.data.tel,
        secret:this.data.secret,
        other:this.data.other,
        ok:this.data.ok
      },
      success: function (res) {
        console.log(res)
        
      }
    })
  }  
})
//云数据库初始化
const db = wx.cloud.database({});
const cont = db.collection('test-m0uv2');

Page({
  data: {
    ne: [],
  },
  /**
  * 生命周期函数--监听页面加载
  */
  onLoad: function (options) {
    var _this = this;
    const db = wx.cloud.database({
      env: ''
    })
    //2、开始查询数据了 news对应的是集合的名称 
    db.collection('fastpass').get({
      success: res => {
        console.log(res.data)
        this.setData({
          ne: res.data
        })
      }
    })
  },
  goToChat:function(param){
    wx.navigateTo({
      url: '/pages/chatroom/chatroom',
    })
  },
  a1: function () {
    wx.navigateTo({
      url: '../chatroom/chatroom'
    })
  },
  a2: function () {
    wx.navigateTo({
      url: '../chatroom/chatroom'
    })
  },
  a3: function () {
    wx.navigateTo({
      url: '../chatroom/chatroom'
    })
  },
  a4: function () {
    wx.navigateTo({
      url: '../chatroom/chatroom'
    })
  },
  a5: function () {
    wx.navigateTo({
      url: '../chatroom/chatroom'
    })
  },
  a6: function () {
    wx.navigateTo({
      url: '../chatroom/chatroom'
    })
  },
  a7: function () {
    wx.navigateTo({
      url: '../chatroom/chatroom'
    })
  },
  a8: function () {
    wx.navigateTo({
      url: '../chatroom/chatroom'
    })
  },
  a9: function () {
    wx.navigateTo({
      url: '../chatroom/chatroom'
    })
  },
  a10: function () {
    wx.navigateTo({
      url: '../chatroom/chatroom'
    })
  }
})
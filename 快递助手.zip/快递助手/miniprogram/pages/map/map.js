//index.js

//获取应用实例

const app = getApp()

Page({

  data: {

  },

  onShow: function () {

    //初始获取定位权限

    wx.authorize({

      scope: 'scope.userLocation',

      success: (res) => {



      },

    })

  },

  map: function () {

    wx.getLocation({

      type: 'gcj02', //返回可以用于wx.openLocation的经纬度

      success: function (res) {

        var latitude = res.latitude

        var longitude = res.longitude

        wx.openLocation({

          latitude: latitude,

          longitude: longitude,

          scale: 18

        })

        wx.openLocation({

          latitude: this.data.activityInfo.latitude,

          longitude: this.data.activityInfo.longitude,
        })

      }

    })

  }

})
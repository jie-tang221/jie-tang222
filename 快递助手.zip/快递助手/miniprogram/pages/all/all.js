var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    wide: "",
    high: ""
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this
    var sysInfo = wx.getSystemInfoSync();
    var winHeight = sysInfo.windowHeight;
    var winLength = sysInfo.windowWidth;
    this.setData({
      wide: winHeight,
      high: winLength
    })
  },



  tapone: function () {
    wx.navigateTo({
      url: '../get/get'
    })
  },

  taptwo: function () {
    wx.navigateTo({
      url: '../get-waimai/get-waimai'
    })
  },
  tapthree: function () {
    wx.navigateTo({
      url: '../get-lost/get-lost'
    })
  }
})
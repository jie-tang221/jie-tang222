const app=getApp()// pages/lost/lost.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    shows: false,
    name: "",
    tel: "",
    id: "",
    infor:"",
    image:"",
    ok: 0
  },

  name: function (e) {
    this.setData({
      name: e.detail.value
    })
  },

  tel: function (e) {
    this.setData({
      tel: e.detail.value
    })
  },

  id: function (e) {
    this.setData({
      id: e.detail.value
    })
  },
  infor: function (e) {
    this.setData({
      infor: e.detail.value
    })
  },
  image: function (e) {
    this.setData({
      image: e.detail.value
    })
  },
onLoad: function (options) {
  if (app.globalData.openid) {
    this.setData({
      openid: app.globalData.openid
    })
  }
},

choose:function(){
  var that=this;
  wx.chooseImage({
    count:1,
    sourceType:"album",
    success(res) {
      const image = res.tempFilePaths;
      that.setData({
        image: image
      })
    },  
  })
  
},

upload: function () {
  const db = wx.cloud.database()
  db.collection("lost").add({
    data: {
      name: this.data.name,
      tel: this.data.tel,
      id: this.data.id,
      infor: this.data.infor,
      image:this.data.image
    },
    success: function (res) {
      console.log(res)

    }
  })
}
})
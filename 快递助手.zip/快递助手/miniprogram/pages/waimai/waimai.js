const app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    shows: false,
    name: "",
    tel: "",
    id: "",
    other: "",
    ok: 0
  },

  switch1Change: function (e) {
    this.setData({
      shows: e.detail.value
    });
  },

  name: function (e) {
    this.setData({
      name: e.detail.value
    })
  },

  tel: function (e) {
    this.setData({
      tel: e.detail.value
    })
  },

  id: function (e) {
    this.setData({
      id: e.detail.value
    })
  },

 

  other: function (e) {
    this.setData({
      other: e.detail.value
    })
  },

  upload: function () {
    const db = wx.cloud.database()
    db.collection("waimai").add({
      data: {
        name: this.data.name,
        tel: this.data.tel,
        id: this.data.id,
        other: this.data.other,
        ok: this.data.ok
      },
      success: function (res) {
        console.log(res)

      }
    })
  }
})